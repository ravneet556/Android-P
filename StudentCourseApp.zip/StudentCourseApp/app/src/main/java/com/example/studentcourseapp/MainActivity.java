package com.example.studentcourseapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity implements View.OnClickListener , AdapterView.OnItemSelectedListener {
TextView welcome,fees,hours,label,totalf,totalh;
RadioButton graduate,ungraduate;
Spinner spin;
CheckBox accommodation,medical;
Button submit;
    String courses[] = {"Java", "Swift", "IOS","Android","Database"};
    String Fees[] = {"1300", "1500", "1350","1400","1000"};
    String Hours[]={"6","5","5","7","4"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        welcome = findViewById(R.id.txtMessage);
        welcome.setText("Welcome " +  LoginPage.name.getText());
        fees = findViewById(R.id.txtFees);
        hours = findViewById(R.id.txtHours);
        label = findViewById(R.id.txtLabel);
        totalf = findViewById(R.id.txtTFees);
        totalh = findViewById(R.id.txtTHours);
        graduate = findViewById(R.id.rbGrad);
        ungraduate = findViewById(R.id.rbUnGrad);
        spin = findViewById(R.id.spCourses);
        accommodation = findViewById(R.id.txtAcc);
        medical= findViewById(R.id.txtMedical);
        submit= findViewById(R.id.txtSubmit);
        submit.setOnClickListener(this);
        spin.setOnItemSelectedListener(this);
        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_item, courses);
        //set the array adapter as simple spinner
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //Setting the ArrayAdapter data to the Spinner
        spin.setAdapter(aa);

    }

    @Override
    public void onClick(View view) {
        double f = 0,h=0;
       int  i = spin.getSelectedItemPosition();


        fees.setText(Fees[i]);
        hours.setText(Hours[i]);
        f = new Double(Fees[i]);
       h = new Double(Hours[i]);

       if (graduate.isChecked()) {
           if(medical.isChecked()){
               f = f + 700;
            String t = String.format("%.2f", f);
                totalf.setText(t);
                String tt = String.format("%.2f",h);
               Double ttt = new Double(tt);
               if( ttt < 21){
                   totalh.setText(tt);
               }
            else{
                label.setText("21  hours only");
               }


           }
           else if(accommodation.isChecked()){
               f = f + 1000;
               String t = String.format("%.2f", f);
               totalf.setText(t);
               String tt = String.format("%.2f",h);
               Double ttt = new Double(tt);
               if( ttt < 21){
                   totalh.setText(tt);
               }
               else{
                   label.setText("21 hours only ");
               }

           }
           else if(medical.isChecked() && accommodation.isChecked()){
               f = f + 1000 + 700;
               String t = String.format("%.2f", f);
               totalf.setText(t);
               String tt = String.format("%.2f", h);
               Double ttt = new Double(tt);
               if( ttt < 21){
                   totalh.setText(tt);
               }
               else{
                   label.setText("21 hours only ");
               }
           }
           else{
               String t = String.format("%.2f", f);
               totalf.setText(t);
               String tt = String.format("%.2f",h);
               Double ttt = new Double(tt);
               if( ttt < 21){
                   totalh.setText(tt);
               }
               else{
                   label.setText("21 hours only ");
               }
           }

            }

            else if(ungraduate.isChecked()) {
           if (medical.isChecked()) {
               f = f + 700;
               String t = String.format("%.2f", f);
               totalf.setText(t);
               String tt = String.format("%.2f", h);
               Double ttt = new Double(tt);
               if( ttt < 19){
                   totalh.setText(tt);
               }
               else{
                   label.setText("19 hours  only");
               }

           } else if (accommodation.isChecked()) {
               f = f + 1000;
               String t = String.format("%.2f", f);
               totalf.setText(t);
               String tt = String.format("%.2f", h);
               Double ttt = new Double(tt);
               if( ttt < 19){
                   totalh.setText(tt);
               }
               else{
                   label.setText("19 hours  only");
               }
           }
           else if(medical.isChecked() && accommodation.isChecked()){
               f = f + 1000 + 700;
               String t = String.format("%.2f", f);
               totalf.setText(t);
               String tt = String.format("%.2f", h);
               Double ttt = new Double(tt);
               if( ttt < 19){
                   totalh.setText(tt);
               }
               else{
                   label.setText("19 hours  only");
               }
           }
                   else {
               String t = String.format("%.2f", f);
               totalf.setText(t);
               String tt = String.format("%.2f", h);
               Double ttt = new Double(tt);
               if( ttt < 19){
                   totalh.setText(tt);
               }
               else{
                   label.setText("19 hours  only");
               }
           }

       }


    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        fees.setText(Fees[i]);
        hours.setText(Hours[i]);

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
